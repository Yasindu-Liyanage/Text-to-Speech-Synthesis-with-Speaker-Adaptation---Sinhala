import { IncomingForm } from "formidable";
import fs from "fs";
import path from "path";
import type { NextApiRequest, NextApiResponse } from "next";

export const config = {
  api: {
    bodyParser: false, // Disallow body parsing, since formidable handles it
  },
};

const handler = async (req: NextApiRequest, res: NextApiResponse) => {
  if (req.method !== "POST") {
    return res.status(405).json({ error: "Method not allowed" });
  }

  const form = new IncomingForm();
  const uploadDir = path.join(process.cwd(), "/Audios");

  // Ensure folder exists
  fs.mkdirSync(uploadDir, { recursive: true });

  form.uploadDir = uploadDir;
  form.keepExtensions = true;
  form.maxFileSize = 10 * 1024 * 1024; // 10MB

  form.parse(req, (err, fields, files) => {
    if (err) {
      console.error("Form parse error:", err);
      return res.status(500).json({ error: "Error parsing the file" });
    }

    const file = files.audio?.[0] || files.audio; // Handle single or multiple files
    if (!file) return res.status(400).json({ error: "No file uploaded" });

    const newFilePath = path.join(uploadDir, file.originalFilename || file.newFilename);
    fs.renameSync(file.filepath, newFilePath);

    const publicPath = `/Audios/${path.basename(newFilePath)}`;
    return res.status(200).json({ file_path: publicPath });
  });
};

export default handler;
